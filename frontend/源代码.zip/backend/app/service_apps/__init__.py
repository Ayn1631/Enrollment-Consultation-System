"""Standalone microservice apps."""

