from __future__ import annotations

import logging
import time
from collections.abc import Iterator

import httpx

from app.config import Settings
from app.contracts import (
    CitationGuardResponse,
    ConversationTurn,
    GenerationRequest,
    GenerationResponse,
    GenerationStreamChunk,
    MemoryCompressionRequest,
    MemoryCompressionResponse,
    MemoryCompressionResult,
    MemoryEntry,
    MemoryQuery,
    MemoryReadResponse,
    MemoryWriteRequest,
    RagQueryRequest,
    RagQueryResponse,
    SkillExecuteRequest,
    SkillExecuteResponse,
    SkillListResponse,
    SkillSaveRequest,
)
from app.models import ChatSource, FeatureFlag
from app.admissions_kb.tools import StructuredAdmissionsToolset
from app.rag.service import RagGraphService
from app.services.ai_stack import LangChain4jSkillBridge, LangGraphFeaturePlanner
from app.services.llm import GenerationService
from app.services.memory import MemoryManager
from app.services.skill_manager import SkillManager


logger = logging.getLogger(__name__)


class ServiceClient:
    """统一封装本地/远程服务调用，供网关与管理接口复用。"""

    def __init__(self, settings: Settings):
        # 关键变量：service_call_mode 决定是否走 HTTP 微服务调用。
        self.settings = settings
        self._memory = MemoryManager(settings.local_memory_db_path)
        self._skills = SkillManager()
        self._generator = GenerationService(settings)
        self._feature_planner = LangGraphFeaturePlanner()
        self._admissions_toolset = StructuredAdmissionsToolset(settings)
        self._langchain4j_bridge = LangChain4jSkillBridge(
            base_url=settings.langchain4j_service_url,
            timeout_seconds=settings.langchain4j_timeout_seconds,
        )
        self._rag_service: RagGraphService | None = None
        self._http_clients: dict[float, httpx.Client] = {}

    def startup(self) -> None:
        """启动本地依赖；HTTP 模式由独立服务负责初始化。"""
        if self.settings.service_call_mode == "http":
            self._get_http_client(self.settings.request_timeout_seconds)
        if self.settings.service_call_mode != "http":
            self._get_rag_service().startup()

    def shutdown(self) -> None:
        for client in self._http_clients.values():
            client.close()
        self._http_clients.clear()
        self._generator.close()

    def _get_http_client(self, timeout: float) -> httpx.Client:
        client = self._http_clients.get(timeout)
        if client is None:
            client = httpx.Client(timeout=timeout)
            self._http_clients[timeout] = client
        return client

    def _get_rag_service(self) -> RagGraphService:
        service = self._rag_service
        if service is None:
            service = RagGraphService(self.settings)
            self._rag_service = service
        return service

    def _post(self, url: str, payload: dict, timeout: float) -> dict:
        last_error: Exception | None = None
        client = self._get_http_client(timeout)
        for attempt in range(2):
            try:
                response = client.post(url, json=payload)
                response.raise_for_status()
                return response.json()
            except Exception as exc:  # noqa: BLE001
                last_error = exc
                if attempt == 0:
                    time.sleep(0.02)
        if last_error is not None:
            raise last_error
        raise RuntimeError("post request failed with unknown reason")

    def run_rag_graph(
        self,
        session_id: str,
        query: str,
        top_k: int = 8,
        debug: bool = False,
        memory_context_blocks: list[str] | None = None,
    ) -> RagQueryResponse:
        """执行 LangGraph RAG 工作流。"""
        request = RagQueryRequest(
            session_id=session_id,
            query=query,
            top_k=top_k,
            debug=debug,
            memory_context_blocks=list(memory_context_blocks or []),
        )
        print(
            f"[ServiceClient] run_rag_graph start session_id={session_id} top_k={top_k} "
            f"debug={debug} memory_blocks={len(request.memory_context_blocks)} query={query[:80]}"
        )
        if self.settings.service_call_mode == "http":
            body = self._post(
                f"{self.settings.rag_agent_service_url}/rag/query",
                request.model_dump(),
                self.settings.rag_agent_service_timeout_seconds,
            )
            result = RagQueryResponse.model_validate(body)
            logger.info(
                "[ServiceClient] run_rag_graph http result status=%s sources=%s degrade_reason=%s",
                result.status,
                len(result.sources),
                result.degrade_reason,
            )
            return result
        result = self._get_rag_service().run(
            session_id=session_id,
            query=query,
            top_k=top_k,
            debug=debug,
            memory_context_blocks=request.memory_context_blocks,
        )
        logger.info(
            "[ServiceClient] run_rag_graph local result status=%s sources=%s degrade_reason=%s latency=%s",
            result.status,
            len(result.sources),
            result.degrade_reason,
            result.latency_ms,
        )
        print(
            f"[ServiceClient] run_rag_graph done status={result.status} "
            f"sources={len(result.sources)} degrade_reason={result.degrade_reason}"
        )
        return result

    def query_admissions_structured(self, *, query: str) -> RagQueryResponse | None:
        payloads = [
            self._admissions_toolset.major_catalog_lookup(raw_query=query, filters={}, limit=8),
            self._admissions_toolset.scoreline_lookup(raw_query=query, filters={}, limit=8),
            self._admissions_toolset.policy_table_lookup(raw_query=query, filters={}, limit=12),
        ]
        best_payload = self._admissions_toolset.choose_best_payload(payloads, raw_query=query)
        if best_payload is None:
            return None
        trace_id = f"structured-{best_payload.tool_name}"
        return self._admissions_toolset.to_rag_response(payload=best_payload, trace_id=trace_id)

    def write_short_memory(self, session_id: str, key: str, value: str) -> None:
        self.write_memory(session_id=session_id, entry=MemoryEntry(key=key, value=value, kind="short"))

    def read_short_memory(self, session_id: str) -> MemoryReadResponse:
        return self.read_memory(session_id=session_id, kind="short")

    def write_memory(self, session_id: str, entry: MemoryEntry) -> None:
        request = MemoryWriteRequest(session_id=session_id, entry=entry)
        if self.settings.service_call_mode == "http":
            self._post(
                f"{self.settings.memory_service_url}/memory/write",
                request.model_dump(mode="json"),
                self.settings.memory_service_timeout_seconds,
            )
            return
        self._memory.write(session_id, request.entry)

    def read_memory(self, session_id: str, kind: str, key: str | None = None) -> MemoryReadResponse:
        query = MemoryQuery(session_id=session_id, key=key)
        if self.settings.service_call_mode == "http":
            body = self._post(
                f"{self.settings.memory_service_url}/memory/read?kind={kind}",
                query.model_dump(),
                self.settings.memory_service_timeout_seconds,
            )
            return MemoryReadResponse.model_validate(body)
        entries = self._memory.read(session_id, kind=kind, key=key)
        return MemoryReadResponse(entries=entries)

    def append_long_memory_summary(self, session_id: str, snippet: str) -> MemoryEntry:
        if self.settings.service_call_mode == "http":
            existing = self.read_memory(session_id=session_id, kind="long", key="rolling_summary").entries
            previous = existing[0].value if existing else ""
            merged = f"{previous} | {snippet}".strip(" |")[-600:]
            entry = MemoryEntry(key="rolling_summary", value=merged, kind="long", confidence=0.72, source="rolling_summary")
            self.write_memory(session_id=session_id, entry=entry)
            return entry
        return self._memory.append_long_summary(session_id=session_id, snippet=snippet)

    def compress_memories(self, request: MemoryCompressionRequest) -> MemoryCompressionResponse:
        print(
            f"[ServiceClient] compress_memories start session_id={request.session_id} "
            f"messages={len(request.messages)} session_title={request.session_title or ''}"
        )
        if self.settings.service_call_mode == "http":
            body = self._post(
                f"{self.settings.generation_service_url}/memory/compress",
                request.model_dump(mode='json'),
                self.settings.generation_service_timeout_seconds,
            )
            result = MemoryCompressionResponse.model_validate(body)
            print(
                f"[ServiceClient] compress_memories http done long={result.long_memory_count} "
                f"special={result.special_memory_count} route={result.route} model={result.model}"
            )
            return result

        result = self._generator.compress_memories(
            session_id=request.session_id,
            session_title=request.session_title,
            messages=request.messages,
        )
        return self._persist_memory_compression(request=request, result=result)

    def execute_skill(self, query: str, session_id: str, saved_skill_id: str | None = None) -> SkillExecuteResponse:
        """技能执行入口：保存技能优先走 LangChain4j 桥接，失败后回退本地策略。"""
        request = SkillExecuteRequest(query=query, session_id=session_id, saved_skill_id=saved_skill_id)
        if self.settings.service_call_mode == "http":
            body = self._post(
                f"{self.settings.skill_service_url}/skills/execute",
                request.model_dump(),
                self.settings.skill_service_timeout_seconds,
            )
            return SkillExecuteResponse.model_validate(body)
        if saved_skill_id:
            bridge_note = self._langchain4j_bridge.execute(
                query=query,
                session_id=session_id,
                saved_skill_id=saved_skill_id,
            )
            if bridge_note:
                return SkillExecuteResponse(note=bridge_note)
            note = self._skills.execute_saved(saved_skill_id, query)
            return SkillExecuteResponse(note=note)
        note = self._skills.execute_general(query)
        return SkillExecuteResponse(note=note)

    def plan_features(self, features: list[FeatureFlag]) -> list[FeatureFlag]:
        """Agent 功能规划入口：agent_stack=langgraph 时启用图规划。"""
        if self.settings.agent_stack.lower() == "langgraph":
            return self._feature_planner.plan(features=features)
        return self._feature_planner.fallback_plan(features=features)

    def list_saved_skills(self) -> SkillListResponse:
        if self.settings.service_call_mode == "http":
            response = self._get_http_client(self.settings.saved_skill_service_timeout_seconds).get(
                f"{self.settings.skill_service_url}/skills/saved?active_only=true",
            )
            response.raise_for_status()
            body = response.json()
            return SkillListResponse.model_validate(body)
        return SkillListResponse(skills=self._skills.list_active())

    def save_skill(self, name: str, workflow: str):
        request = SkillSaveRequest(name=name, workflow=workflow)
        if self.settings.service_call_mode == "http":
            body = self._post(
                f"{self.settings.skill_service_url}/skills/save",
                request.model_dump(),
                self.settings.skill_service_timeout_seconds,
            )
            return body
        return self._skills.save(name=name, workflow=workflow).model_dump(mode="json")

    def generate(self, request: GenerationRequest) -> GenerationResponse:
        print(
            f"[ServiceClient] generate start model={request.model or 'auto'} "
            f"context_blocks={len(request.context_blocks)} feature_notes={len(request.feature_notes)}"
        )
        if self.settings.service_call_mode == "http":
            body = self._post(
                f"{self.settings.generation_service_url}/generate",
                request.model_dump(),
                self.settings.generation_service_timeout_seconds,
            )
            result = GenerationResponse.model_validate(body)
            logger.info(
                "[ServiceClient] generate http result route=%s model=%s cache_hit=%s",
                result.route,
                result.model,
                result.cache_hit,
            )
            return result
        result = self._generator.generate(
            user_query=request.user_query,
            context_blocks=request.context_blocks,
            feature_notes=request.feature_notes,
            model=request.model,
            temperature=request.temperature,
            top_p=request.top_p,
        )
        logger.info(
            "[ServiceClient] generate local result route=%s model=%s cache_hit=%s text_preview=%s",
            result.route,
            result.model,
            result.cache_hit,
            result.text[:120],
        )
        print(
            f"[ServiceClient] generate done route={result.route} model={result.model} "
            f"cache_hit={result.cache_hit}"
        )
        return result

    def stream_generate(self, request: GenerationRequest) -> Iterator[GenerationStreamChunk]:
        print(
            f"[ServiceClient] stream_generate start model={request.model or 'auto'} "
            f"context_blocks={len(request.context_blocks)} feature_notes={len(request.feature_notes)}"
        )
        if self.settings.service_call_mode == "http":
            raise RuntimeError("stream generate is only supported in local mode")
        for chunk in self._generator.stream_generate(
            user_query=request.user_query,
            context_blocks=request.context_blocks,
            feature_notes=request.feature_notes,
            model=request.model,
            temperature=request.temperature,
            top_p=request.top_p,
        ):
            if chunk.done and chunk.response is not None:
                logger.info(
                    "[ServiceClient] stream_generate local done route=%s model=%s cache_hit=%s text_preview=%s",
                    chunk.response.route,
                    chunk.response.model,
                    chunk.response.cache_hit,
                    chunk.response.text[:120],
                )
                print(
                    f"[ServiceClient] stream_generate done route={chunk.response.route} "
                    f"model={chunk.response.model} cache_hit={chunk.response.cache_hit}"
                )
            yield chunk

    def citation_guard(self, sources: list[ChatSource]) -> CitationGuardResponse:
        print(
            f"[ServiceClient] citation_guard sources={len(sources)} "
            f"source_titles={[item.title for item in sources[:5]]}"
        )
        logger.info(
            "[ServiceClient] citation_guard sources=%s urls=%s",
            len(sources),
            [item.url for item in sources[:5]],
        )
        return CitationGuardResponse(ok=len(sources) > 0)

    def dependency_health(self) -> dict[str, dict[str, str | bool]]:
        if self.settings.service_call_mode != "http":
            return {
                "rag-agent-service": {"healthy": True, "detail": "local mode"},
                "memory-service": {"healthy": True, "detail": "local mode"},
                "skill-service": {"healthy": True, "detail": "local mode"},
                "generation-service": {"healthy": True, "detail": "local mode"},
            }

        targets = {
            "rag-agent-service": f"{self.settings.rag_agent_service_url}/rag/healthz",
            "memory-service": f"{self.settings.memory_service_url}/healthz",
            "skill-service": f"{self.settings.skill_service_url}/healthz",
            "generation-service": f"{self.settings.generation_service_url}/healthz",
        }
        health: dict[str, dict[str, str | bool]] = {}
        for name, url in targets.items():
            try:
                res = self._get_http_client(0.8).get(url)
                res.raise_for_status()
                health[name] = {"healthy": True, "detail": "ok"}
            except Exception as exc:  # noqa: BLE001
                health[name] = {"healthy": False, "detail": str(exc)}
        return health

    def reindex(self, *, show_progress: bool = False) -> dict:
        if self.settings.service_call_mode == "http":
            request_kwargs: dict[str, object] = {}
            if show_progress:
                request_kwargs["params"] = {"show_progress": "true"}
            response = self._get_http_client(15).post(
                f"{self.settings.rag_agent_service_url}/rag/reindex",
                **request_kwargs,
            )
            response.raise_for_status()
            return response.json()
        return self._get_rag_service().reindex(show_progress=show_progress)

    def rag_stats(self) -> dict:
        if self.settings.service_call_mode == "http":
            response = self._get_http_client(5).get(
                f"{self.settings.rag_agent_service_url}/rag/stats",
            )
            response.raise_for_status()
            return response.json()
        return self._get_rag_service().stats()

    def _persist_memory_compression(
        self,
        *,
        request: MemoryCompressionRequest,
        result: MemoryCompressionResult,
    ) -> MemoryCompressionResponse:
        long_count = 0
        special_count = 0
        if result.long_summary:
            self.append_long_memory_summary(request.session_id, result.long_summary)
            long_count += 1
        for entry in result.long_entries:
            self.write_memory(request.session_id, entry)
            long_count += 1
        for entry in result.special_entries:
            self.write_memory(request.session_id, entry)
            special_count += 1
        response = MemoryCompressionResponse(
            session_id=request.session_id,
            long_summary=result.long_summary,
            long_memory_count=long_count,
            special_memory_count=special_count,
            route=result.route,
            model=result.model,
            notes=result.notes,
        )
        print(
            f"[ServiceClient] compress_memories done session_id={request.session_id} "
            f"long={response.long_memory_count} special={response.special_memory_count} "
            f"route={response.route} model={response.model}"
        )
        logger.info(
            "[ServiceClient] compress_memories done session_id=%s long=%s special=%s route=%s model=%s notes=%s",
            request.session_id,
            response.long_memory_count,
            response.special_memory_count,
            response.route,
            response.model,
            response.notes,
        )
        return response
